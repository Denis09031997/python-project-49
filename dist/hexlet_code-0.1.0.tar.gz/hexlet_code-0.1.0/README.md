### Hexlet tests and linter status:
[![Actions Status](https://github.com/Denis09031997/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Denis09031997/python-project-49/actions)



[![Maintainability](https://codeclimate.com/github/Denis09031997/python-project-49/maintainability)](https://api.codeclimate.com/v1/badges/1a1672f6a852b8daf702/maintainability)


[![asciinema](https://asciinema.org/a/HklCufok8ueHp1529PAQmBrcD)]